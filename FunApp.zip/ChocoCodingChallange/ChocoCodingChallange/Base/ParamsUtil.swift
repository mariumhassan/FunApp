//
//  BaseService.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//


import Foundation
import UIKit

class ParamsUtil: NSObject{
    
    static let sharedInstance = ParamsUtil()
    var requestHeaders = [String:String]()
    var baseUrl:String
    var isUserloggedIn:Bool = false
    var isOrderCacheUpdated:Bool = false
    private override init(){
        baseUrl = "https://qo7vrra66k.execute-api.eu-west-1.amazonaws.com/choco/"
    }
    
    func addSessionToken(value:String){
        requestHeaders = [
           "Authorization" :  value
        ]
    }
    
    func removeSessionData(){
        requestHeaders = [String:String]()
        self.isUserloggedIn = false
    }
    
}

 
