//
//  LocalDbManager.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//


import CoreData
import UIKit

enum DBManagerError:Error{
    case zeroProductsError
}


class LocalDbManager{
    
    static let sharedInstance = LocalDbManager()
    var objectContext:NSManagedObjectContext?
    
    private init(){
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        objectContext = appdelegate.persistentContainer.viewContext
    }
    
    func createOrder(orderObj:Orders) throws {
        
        if let  managedObjectContext = objectContext
        {
            var totalPrice = 0
            let todoOrderObj = Order(context: managedObjectContext)
            todoOrderObj.id = String(Int.random(in: 1...1000))
            todoOrderObj.name = "Test Order " + (todoOrderObj.id ?? "")
            todoOrderObj.desc = "Test Order Containing " + String((orderObj.orderItems.count )) + " Products"
            
            
            let products = orderObj.orderItems
            if products.count <= 0 {
                throw DBManagerError.zeroProductsError
            }
            for item in products{
                let todoObj = Product(context: managedObjectContext)
                todoObj.id = item.Id
                todoObj.name = item.name
                todoObj.desc = item.Description
                todoObj.price = String( (item.price ?? 0) )
                todoObj.photoUrl = item.photo
                todoObj.quantity = String(item.qunatity ?? 1)
                totalPrice += item.price ?? 0
                todoOrderObj.addToProducts(todoObj)
                todoObj.addToOrder(todoOrderObj)
                
            }
            
            todoOrderObj.price = String(totalPrice)
            
            do {
                try managedObjectContext.save()
            }
            catch {
                throw error
            }
            
        }
        
    }
    
    func fetchOrders() throws -> [Orders]{
        
        var orderList = [Orders]()
        if let  managedObjectContext = objectContext
        {
            let fetchRequest1: NSFetchRequest<Order> = Order.fetchRequest()
            do {
                
                let orders = try managedObjectContext.fetch(fetchRequest1)
                for orderItem in orders{
                    var orderObj = Orders(orderId: orderItem.id ?? "", orderName: orderItem.name ?? "", orderDesc: orderItem.desc ?? "", orderPrice: orderItem.price ?? "", orderItems: [ProductModel]())
                    if let products = orderItem.products as? Set<Product>{
                        for tempObj in products{
                            
                            let productObj = ProductModel(Id: tempObj.id, name: tempObj.name, Description: tempObj.desc, price: Int(tempObj.price ?? ""), photo: tempObj.photoUrl,qunatity: Int(tempObj.quantity ?? ""))
                            orderObj.orderItems.append(productObj)
                            
                            
                        }
                    }
                    
                    orderList.append(orderObj)
                }
                return orderList
                
            } catch {
                throw error
                
            }
        }
        
        return orderList
    }
    
    func deleteProduct(withId Id: String, orderIndex index:Int) throws {
        
        if let  managedObjectContext = objectContext
        {
            let fetchRequest1: NSFetchRequest<Order> = Order.fetchRequest()
            do {
                
                let orders = try managedObjectContext.fetch(fetchRequest1)
                
                if orders.count > 0{
                    if let products = orders[index].products as? Set<Product>{
                        for tempObj in products {
                            if (tempObj.value(forKey: "id") as? String) == Id{
                                orders[index].removeFromProducts(tempObj)
                                managedObjectContext.delete(tempObj)
                            }
                            
                        }
                
                        try managedObjectContext.save()
                    }
                }
                
            } catch {
                throw error
            }
        }
        
    }
    
    
    func updateOrder(orderIndex index:Int,order:Orders) throws{
        
        if let  managedObjectContext = objectContext
        {
            let fetchRequest1: NSFetchRequest<Order> = Order.fetchRequest()
            do {
                
                let orders = try managedObjectContext.fetch(fetchRequest1)
                
                if let products = orders[index].products as? Set<Product>{
                    if products.count <= 0{
                        managedObjectContext.delete(orders[index])
                    }
                    else{
                        orders[index].setValue(order.orderPrice, forKey: "price")
                        orders[index].setValue("Test Order Containing " + String((order.orderItems.count)) + " Products", forKey: "desc")
                    }
                }
                try managedObjectContext.save()
                
            }
            catch {
                throw error
            }
        }
        
    }
    
    
    func updateProductQuan(orderIndex index:Int, order:Orders) throws {
        
        if let  managedObjectContext = objectContext
        {
            let fetchRequest1: NSFetchRequest<Order> = Order.fetchRequest()
            do {
                
                let orders = try managedObjectContext.fetch(fetchRequest1)
                if let products = orders[index].products as? Set<Product>{
                    for (tempObj) in (products){
                        let proj = order.orderItems.filter({$0.name == tempObj.name})
                        if let quan = proj[0].qunatity {
                            tempObj.setValue(String(quan), forKey: "quantity")
                            try managedObjectContext.save()
                        }
                        
                    }
                }
            
                orders[index].setValue(order.orderPrice, forKey: "price")
                try managedObjectContext.save()
                
            } catch {
                throw error
                
            }
        }
    }
    
    
}

