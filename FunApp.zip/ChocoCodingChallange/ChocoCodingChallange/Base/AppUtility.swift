//
//  BaseService.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//


import Foundation
import UIKit

class AppUtility: NSObject{
    
    
    class func showAlert(_ message:String, _ completion: ((_ action:UIAlertAction) -> ())? = nil){
        
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "alert", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: completion))
            
            var rootViewController = UIApplication.shared.keyWindow?.rootViewController
            if let navigationController = rootViewController as? UINavigationController {
                rootViewController = navigationController.viewControllers.first
            }
            if let tabBarController = rootViewController as? UITabBarController {
                rootViewController = tabBarController.selectedViewController
            }
            rootViewController?.present(alert, animated: true, completion: nil)
        }
        
    }
    
    class func logOutUser(){
        ParamsUtil.sharedInstance.removeSessionData()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let loginController = storyboard.instantiateViewController(identifier: "LoginVC")
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.setRootViewController(loginController)
    }
    
    class func addSessionData(token:String){
        ParamsUtil.sharedInstance.addSessionToken(value: token)
        ParamsUtil.sharedInstance.isUserloggedIn = true
    }
    
    
}



