//
//  BaseService.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//


import Foundation
import Alamofire


class BaseService: NSObject {
    
    var parameters = [String:String]()
    
    func execute<T:Codable>(action:String, completionHandler responseBlock: @escaping (Result<BaseResponse<T>,Error>?) -> Void) {
        
        var headers = HTTPHeaders(ParamsUtil.sharedInstance.requestHeaders)
        let requestString = "\(ParamsUtil.sharedInstance.baseUrl)\(action)"
        var method = HTTPMethod.get
        var encoding:ParameterEncoding
        if action == "login?"{
            method = HTTPMethod.post
            encoding = JSONEncoding.default
        }else{
            encoding = URLEncoding.default
            headers = HTTPHeaders(ParamsUtil.sharedInstance.requestHeaders)
            parameters["token"] = (headers["Authorization"] ?? "")
        }
        
        
        AF.request(requestString,
                   method:method,
                   parameters: parameters,
                   encoding:encoding,
                   headers: headers).responseJSON(completionHandler: { response in
                    print(response)
                    
                    switch(response.result){
                    
                    case .success(let JSON):
                        
                        guard let theJSONData = try? JSONSerialization.data(withJSONObject: JSON, options: []) else {
                            
                            return
                        }
                        guard let responseObj = try? JSONDecoder().decode(T.self, from: theJSONData) else {
                            
                            
                            return
                        }
                        let datObj = BaseResponse(data: responseObj)
                        responseBlock(.success(datObj))
                       
                    case .failure(let error):
                        responseBlock(.failure(error))
                        
                    default:
                        responseBlock(nil)
                        break
                    }
                    
                    
                   })
        
    }
    

}


struct BaseResponse<T:Codable>:Codable{
    var data:T?
}
