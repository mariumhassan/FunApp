//
//  TabBarVC.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

class TabBarVC: UITabBarController, UITabBarControllerDelegate {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
    }

    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool{
        
        if viewController is LogoutVC{
            AppUtility.showAlert("You are going to LogOut" , { _ in
                AppUtility.logOutUser()
            })
           
            return false
        }
        
        return true
    }
    
    
}

