//
//  ViewController.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

protocol productAPIProtocol {
    func fetchProducts(completion: @escaping (Result<BaseResponse<[ProductModel]>,Error>?) -> Void)
}

class ProductService:productAPIProtocol {
    
    var baseService:BaseService?
    
    init(serviceObj:BaseService = BaseService()) {
        self.baseService = serviceObj
    }
    
    func fetchProducts(completion: @escaping (Result<BaseResponse<[ProductModel]>,Error>?) -> Void) {
        self.baseService?.execute(action: "products?", completionHandler: completion)
    }
    
    
}

