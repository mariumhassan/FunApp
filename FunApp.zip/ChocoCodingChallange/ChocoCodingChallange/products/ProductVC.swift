//
//  ProductVC.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit
import SDWebImage
import CoreData

class ProductVC: UIViewController {

    
    // MARK: Outlets
    @IBOutlet weak var Indicator: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    // MARK: - Properties
    lazy var viewModel:ProductViewModel = {
        return ProductViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initView()
        initVM()
    }


    func initView(){
        tableView.estimatedRowHeight = 180
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    func initVM(){
        
        viewModel.updateLoadingStatus = { [weak self] () in
            DispatchQueue.main.async {
                let loading = self?.viewModel.isLoading ?? false
                if loading{
                    self?.Indicator.startAnimating()
                    UIView.animate(withDuration: 0.2, animations: {
                        self?.tableView.alpha = 0.0
                    })
                }else{
                    self?.Indicator?.stopAnimating()
                    UIView.animate(withDuration: 0.2, animations: {
                        self?.tableView.alpha = 1.0
                    })
                }
            }
        }
        
        viewModel.reloadTableViewClosure = { [weak self] () in
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
        
        viewModel.showAlertClosure = { [weak self] in
            
            DispatchQueue.main.async {
                if let message = self?.viewModel.alertMessage {
                    self?.showAlert(message)
                }
                
            }
        }
        
        viewModel.fetchProductslist()
        
    }
    
    func showAlert(_ message:String){
        AppUtility.showAlert(message)
    }
    
    @IBAction func createOrderClicked(_ sender: Any) {
        self.viewModel.createOrder()
    }
}

extension ProductVC: UITableViewDelegate, UITableViewDataSource,cellButtonClick {
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "productCellIdentifier", for: indexPath) as? ProductListTableViewCell else {
            fatalError("Cell not exists in storyboard")
        }
        
        let cellVM = viewModel.getCellViewModel( at: indexPath )
        cell.productListCellViewModel = cellVM
        cell.delegate = self
        cell.indexpath = indexPath
        
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfCells
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.viewModel.userPressed(at: indexPath)
        if let cell = tableView.cellForRow(at: indexPath) as? ProductListTableViewCell{
            let cellVM = viewModel.getCellViewModel( at: indexPath )
            cell.selectBtn.isSelected = cellVM.isSelected
        }
    }
    
    
    func productSelectorClicked(indexPath:IndexPath) {
        self.tableView.delegate?.tableView?(tableView, didSelectRowAt: indexPath)
    }
    

}


protocol cellButtonClick {
    func productSelectorClicked(indexPath:IndexPath)
}

class ProductListTableViewCell: UITableViewCell {
    @IBOutlet weak var selectBtn: UIButton!
    @IBOutlet weak var mainImageView: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descContainerHeightConstraint: NSLayoutConstraint!
    var indexpath:IndexPath?
    var delegate:cellButtonClick?
    var productListCellViewModel : ProductListCellViewModel? {
        didSet {
            nameLabel.text = productListCellViewModel?.nameText
            descriptionLabel.text = productListCellViewModel?.descText
            mainImageView?.sd_setImage(with: URL( string: productListCellViewModel?.imageUrl ?? "" ), placeholderImage: UIImage(named: "default") ,completed: nil)
            priceLabel.text = productListCellViewModel?.priceText
            selectBtn.isSelected = productListCellViewModel?.isSelected ?? false
        }
    }
    
    @IBAction func buttonClicked(_ sender: Any) {
        
        if let indexpath = indexpath{
            self.delegate?.productSelectorClicked(indexPath: indexpath)
        }
        
        
    }
}


