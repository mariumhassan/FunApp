//
//  ProductModel.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit


struct ProductModel:Codable,Equatable,Hashable {

    var Id: String?
    var name: String?
    var Description: String?
    var price: Int?
    var photo: String?
    var qunatity:Int? = 1

}



