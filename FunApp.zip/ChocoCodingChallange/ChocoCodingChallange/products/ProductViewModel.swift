//
//  ViewController.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

class ProductViewModel {

    //MARK: - Properties
    let productService:productAPIProtocol
    private var products:[ProductModel] = [ProductModel]()
    private var orderObj:Orders?
    private var cellViewModels: [ProductListCellViewModel] = [ProductListCellViewModel]() {
        didSet {
            self.reloadTableViewClosure?()
        }
    }
    
    var numberOfCells:Int {
        return cellViewModels.count
    }

    var isLoading:Bool = false{
        didSet{
            self.updateLoadingStatus?()
        }
    }
    
    var alertMessage:String?{
        
        didSet{
            self.showAlertClosure?()
        }
    }
    
    var reloadTableViewClosure: (()->())?
    var showAlertClosure: (()->())?
    var updateLoadingStatus: (()->())?
    
    // MARK: - Methods
    init(productServiceObj:productAPIProtocol = ProductService()) {
        self.productService = productServiceObj
    }
    
    func fetchProductslist(){
        self.isLoading = true
        self.productService.fetchProducts(completion: { [weak self] result in
            self?.isLoading = false
            switch result {
            case .success(let response):
                print(response.data)
                self?.processFetchedProducts(products: (response.data as? [ProductModel])!)
            case .failure(let error):
                print(error)
                self?.alertMessage = error.localizedDescription
            case .none:
                print("")
            }
            
        })
    }
    
    func getCellViewModel( at indexPath: IndexPath ) -> ProductListCellViewModel {
        return cellViewModels[indexPath.row]
    }
    
    func createCellViewModel( product: ProductModel ) -> ProductListCellViewModel {
    
        return ProductListCellViewModel( nameText: product.name ?? "",
                                         descText: product.Description ?? "",
                                         imageUrl: product.photo ?? "",
                                         priceText: ("Price: " + String(product.price ?? 0) ),isSelected: false)
    }
    
    private func processFetchedProducts( products: [ProductModel] ) {
        self.products = products // Cache
        var vms = [ProductListCellViewModel]()
        for product in products {
            vms.append( createCellViewModel(product: product) )
        }
        self.cellViewModels = vms
    }
    
    func userPressed( at indexPath: IndexPath ){
        let product = self.products[indexPath.row]
        let isSelected = !(self.cellViewModels[indexPath.row].isSelected)
        self.cellViewModels[indexPath.row].isSelected = isSelected
        if isSelected {
            if let _ = orderObj{
                orderObj?.orderItems.append(self.products[indexPath.row])
            }else{
                orderObj = Orders(orderItem:[ProductModel]())
                orderObj?.orderItems.append(self.products[indexPath.row])
            }
        }else{
            if ((orderObj?.orderItems.contains( self.products[indexPath.row])) != nil){
                let list = orderObj?.orderItems.filter{ $0.Id != product.Id} ?? [ProductModel]()
                orderObj?.orderItems = list
            }
        }
        
    }
    
    
    func createOrder(){
        
        if let order = self.orderObj{
            
            do{
                try LocalDbManager.sharedInstance.createOrder(orderObj: order)
                self.processFetchedProducts(products: self.products)
                ParamsUtil.sharedInstance.isOrderCacheUpdated = true
                self.orderObj = nil
                self.alertMessage = "Order Created Successfully"
                
            }catch DBManagerError.zeroProductsError {
                self.alertMessage = "Kindly Select atleast one Product to Create Order"
            }catch {
                self.alertMessage = error.localizedDescription
            }
            
        }else{
            self.alertMessage = "Kindly Select atleast one Product to Create Order"
        }
        
        
        
//        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
//        let managedObjectContext = appdelegate.persistentContainer.viewContext
//
//
//        var totalPrice = 0
//        let todoOrderObj = Order(context: managedObjectContext)
//        todoOrderObj.id = String(Int.random(in: 1...1000))
//        todoOrderObj.name = "Test Order " + (todoOrderObj.id ?? "")
//        todoOrderObj.desc = "Test Order Containing " + String((self.orderObj?.orderItems.count ?? 0)) + " Products"
//
//
//        if let products = self.orderObj?.orderItems{
//            if products.count <= 0 {
//                self.alertMessage = "Kindly Select atleast one Product to Create Order"
//                return
//            }
//            for item in products{
//                let todoObj = Product(context: managedObjectContext)
//                todoObj.id = item.Id
//                todoObj.name = item.name
//                todoObj.desc = item.Description
//                todoObj.price = String( (item.price ?? 0) )
//                todoObj.photoUrl = item.photo
//                todoObj.quantity = String(item.qunatity ?? 1)
//                totalPrice += item.price ?? 0
//                todoOrderObj.addToProducts(todoObj)
//                todoObj.addToOrder(todoOrderObj)
//
//            }
//
//            todoOrderObj.price = String(totalPrice)
//
//            do {
//                try managedObjectContext.save()
//                self.processFetchedProducts(products: self.products)
//                ParamsUtil.sharedInstance.isOrderCacheUpdated = true
//                self.alertMessage = "Order Created Successfully"
//            }
//            catch {
//                print("error")
//                self.alertMessage = error.localizedDescription
//            }
//        }
//
        
    }
    
}


struct ProductListCellViewModel {
    let nameText: String
    let descText: String
    let imageUrl: String
    let priceText: String
    var isSelected:Bool
}

