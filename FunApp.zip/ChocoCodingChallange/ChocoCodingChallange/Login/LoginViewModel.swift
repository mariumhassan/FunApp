//
//  ViewController.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

protocol viewModelProtocol {
    func goToNextScreen()
}


class LoginViewModel {

    let loginService:loginAPIProtocol
    var delegate:viewModelProtocol?
    var showAlertClosure: (()->())?
    
    var alertMessage:String?{
        
        didSet{
            self.showAlertClosure?()
        }
    }
    
    
    
    init(loginServiceObj:loginAPIProtocol = LoginService()) {
        self.loginService = loginServiceObj
    }
    
    func loginUser(username:String,password:String){
        self.loginService.login(userName: username, password: password, completion: { [weak self] (result) in
            switch result {
            case .success(let response):
                print(response.data?.token)
                if let token = response.data?.token{
                    AppUtility.addSessionData(token: token)
                    self?.delegate?.goToNextScreen()
                }
            case .failure(let error):
                self?.alertMessage = error.localizedDescription
            case .none:
                print("")
            }
            
        })
    }
    
}

