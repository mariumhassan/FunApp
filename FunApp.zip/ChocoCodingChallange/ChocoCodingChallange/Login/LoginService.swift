//
//  ViewController.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

protocol loginAPIProtocol {
    func login(userName:String,password:String,completion: @escaping (Result<BaseResponse<LoginModel>,Error>?) -> Void)
}

class LoginService:loginAPIProtocol {
    
    var baseService:BaseService?
    
    init(serviceObj:BaseService = BaseService()) {
        self.baseService = serviceObj
    }
    
    func login(userName: String, password: String, completion: @escaping (Result<BaseResponse<LoginModel>,Error>?) -> Void) {
        self.baseService?.parameters["email"] = userName
        self.baseService?.parameters["password"] = password
        self.baseService?.execute(action: "login?",completionHandler: completion)
    }
    
    
}

