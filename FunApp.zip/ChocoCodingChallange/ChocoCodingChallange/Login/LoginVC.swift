//
//  ViewController.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

class LoginVC: UIViewController, viewModelProtocol {
    
    // MARK: Outlets
    @IBOutlet weak var userNameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    
    // MARK: - Properties
    lazy var viewModel:LoginViewModel = {
        return LoginViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewModel.delegate = self
        userNameField.placeholder = "User Name"
        passwordField.placeholder =
        "Password"
        
        userNameField.text = "user@choco.com"
        passwordField.text = "chocorian"
        
        viewModel.showAlertClosure = { [weak self] in
            
            DispatchQueue.main.async {
                if let message = self?.viewModel.alertMessage {
                    self?.showAlert(message)
                }
                
            }
        }
    }

   
    func showAlert(_ message:String){
        AppUtility.showAlert(message)
    }
    
    @IBAction func signInClicked(_ sender: Any) {
        viewModel.loginUser(username: self.userNameField.text ?? "", password: self.passwordField.text ?? "")
    }
    
    func goToNextScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainTabBarController = storyboard.instantiateViewController(identifier: "TabBarVC") as! TabBarVC
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.setRootViewController(mainTabBarController)

    }
    

    
    
}

