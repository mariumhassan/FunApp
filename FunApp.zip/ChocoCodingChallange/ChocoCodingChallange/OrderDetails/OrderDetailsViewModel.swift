//
//  ViewController.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit
import CoreData

class OrderDetailsViewModel {

    //MARK: - Properties
    
     var order:Orders{
        didSet{
            self.processOrder(orders: order)
        }
    }
    private var cellViewModels: [OrderDetailCellViewModel] = [OrderDetailCellViewModel]() {
        didSet {
            self.reloadTableViewClosure?()
        }
    }
    
    var numberOfCells:Int {
        return cellViewModels.count
    }

    var isLoading:Bool = false{
        didSet{
            self.updateLoadingStatus?()
        }
    }
    
    var alertMessage:String?{
        
        didSet{
            self.showAlertClosure?()
        }
    }

    var showAlertClosure: (()->())?
    var reloadTableViewClosure: (()->())?
    var updateLoadingStatus: (()->())?
    
    // MARK: - Methods
    
    init(orderObj:Orders = Orders()){
        self.order = orderObj
    }
    
    func getCellViewModel( at indexPath: IndexPath ) -> OrderDetailCellViewModel {
        return cellViewModels[indexPath.row]
    }
    
    func setOrder(orderObj:Orders?){
        if let order = orderObj{
            self.order = order
        }
       
    }
    
    private func processOrder( orders: Orders?) {
        
        if let order = orders{
            var vms = [OrderDetailCellViewModel]()
            if order.orderItems.count > 0 {
                for product in order.orderItems {
                    vms.append( createCellViewModel(product: product) )
                }
            }else{
                self.alertMessage = "Order Deleted Successfully"
            }
            self.cellViewModels = vms
            
        }
        
    }
    
    func deleteProduct(indexPath: Int) {
        
        let id = self.order.orderItems[indexPath].Id
        let index = self.order.orderIndex
        do {
        
            try LocalDbManager.sharedInstance.deleteProduct(withId: id ?? "", orderIndex: index)
             
            self.manageProdDel(indexPath: indexPath)
            
            
            ParamsUtil.sharedInstance.isOrderCacheUpdated = true
            
        }catch{
            self.alertMessage = error.localizedDescription
        }
        
    }
    
    func manageProdDel(indexPath:Int){
        
        self.deleteProductlocal(at: indexPath)
        do{
            try LocalDbManager.sharedInstance.updateOrder(orderIndex: self.order.orderIndex, order: self.order)
            processOrder(orders: self.order)
        }catch{
            self.alertMessage = error.localizedDescription
        }
        
        
    }
    
    func updateProductquantity(){
        
        do{
            try LocalDbManager.sharedInstance.updateProductQuan(orderIndex: self.order.orderIndex, order: self.order)
            ParamsUtil.sharedInstance.isOrderCacheUpdated = true
            self.alertMessage = "Changes Saved Successfully"
        }catch{
            self.alertMessage = error.localizedDescription
        }
    }
    
    
    func deleteProductlocal(at index:Int){
        
        var orderprice = Int(self.order.orderPrice )
        let productPrice = (self.order.orderItems[index].price ?? 0) * (self.order.orderItems[index].qunatity ?? 0)
        orderprice = (orderprice ?? 0) - (productPrice)
        self.order.orderItems.remove(at: index)
        self.order.orderPrice = String(orderprice ?? 0)
        
    }
    
    func decreaseQunatity(at index:Int){
        
        if self.order.orderItems[index].qunatity ?? 1 > 1{
            
            if let quan = self.order.orderItems[index].qunatity{
                
                self.order.orderItems[index].qunatity = quan - 1
            }
            var orderprice = Int(self.order.orderPrice )
            orderprice = (orderprice ?? 0) - (self.order.orderItems[index].price ?? 0)
            self.order.orderPrice = String(orderprice ?? 0)
            
        }
        
    }
    
    func increaseQunatity(at index:Int){
        
        if let quan = self.order.orderItems[index].qunatity{
            
            self.order.orderItems[index].qunatity = quan + 1
        }
        var orderprice = Int(self.order.orderPrice )
        orderprice = (orderprice ?? 0) + (self.order.orderItems[index].price ?? 0)
        
        self.order.orderPrice = String(orderprice ?? 0)
    }
    
    func createCellViewModel( product: ProductModel ) -> OrderDetailCellViewModel {
    
        return OrderDetailCellViewModel( productNameText: product.name ?? "",
                                         productPriceText: String(product.price ?? 0),
                                         numOfproducts: String(product.qunatity ?? 1),
                                         imgUrl: product.photo ?? ""
                                       )
    }
    
    
}


struct OrderDetailCellViewModel {
    let productNameText: String
    let productPriceText: String
    let numOfproducts:String
    let imgUrl:String
    
}

