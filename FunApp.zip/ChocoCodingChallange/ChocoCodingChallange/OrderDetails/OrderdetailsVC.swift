//
//  OrderdetailsVC.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit
import CoreData

class OrderdetailsVC: UIViewController {

    
    @IBOutlet weak var saveOrderBtn: UIButton!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var NoRecordView: UIView!
    @IBOutlet weak var totalTxt: UILabel!
    @IBOutlet weak var subtotalTxt: UILabel!
    // MARK: Outlets
    @IBOutlet weak var Indicator: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    // MARK: - Properties
    var dataFromPreviousVC:Orders?
    lazy var viewModel:OrderDetailsViewModel = {
        return OrderDetailsViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initView()
        initVM()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.alpha = 1
        self.setPriceLabels()
        self.NoRecordView.isHidden = true
    }
    


    func initView(){
        self.navigationItem.title = "Order Details"
        
        tableView.estimatedRowHeight = 150
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    func initVM(){
        
        viewModel.reloadTableViewClosure = { [weak self] () in
            DispatchQueue.main.async {
                if self?.viewModel.numberOfCells ?? 0 <= 0{
                    self?.showHideNorecord(show:true)
                }else{
                    self?.showHideNorecord(show:false)
                    self?.setPriceLabels()
                    self?.tableView.reloadData()
                }
            }
        }
        
        viewModel.showAlertClosure = { [weak self] in
            
            DispatchQueue.main.async {
                if let message = self?.viewModel.alertMessage {
                    self?.showAlert(message)
                }
                
            }
        }
        
        viewModel.setOrder(orderObj:self.dataFromPreviousVC)
    }
    
    func showHideNorecord(show:Bool){
        self.tableView.isHidden = show
        self.NoRecordView.isHidden = !show
        self.mainView.isHidden = show
        self.saveOrderBtn.isHidden = show
        
    }
    
    func setPriceLabels(){
        self.subtotalTxt.text = "$" + self.viewModel.order.orderPrice
        self.totalTxt.text = "$" +  self.viewModel.order.orderPrice
    }
    
    func showAlert(_ message:String){
        AppUtility.showAlert(message)
    }
    
    @IBAction func saveChnagesClicked(_ sender: Any) {
        self.saveChanges()
    }
}

extension OrderdetailsVC: orderDetailButtonClick{
    
    func quantityDecrease(indexPath: Int) {
        self.viewModel.decreaseQunatity(at: indexPath)
        //setPriceLabels()
    }
    
    func qunatityIncrease(indexPath: Int) {
        self.viewModel.increaseQunatity(at: indexPath)
        //setPriceLabels()
    }
    
    func deleteProduct(indexPath: Int) {
        
        self.viewModel.deleteProduct(indexPath: indexPath)
        
        
//        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
//        let managedObjectContext = appdelegate.persistentContainer.viewContext
//        let index = self.dataFromPreviousVC?.orderIndex ?? 0
//        let prodObj = self.viewModel.order.orderItems[indexPath]
//        let fetchRequest1: NSFetchRequest<Order> = Order.fetchRequest()
//        do {
//
//            let orders = try managedObjectContext.fetch(fetchRequest1)
//
//            if let products = orders[index].products as? Set<Product>{
//                for tempObj in products {
//                    if (tempObj.value(forKey: "id") as? String) == prodObj.Id{
//                        orders[index].removeFromProducts(tempObj)
//                        managedObjectContext.delete(tempObj)
//                    }
//
//                }
//
//                self.viewModel.deleteProduct(at: indexPath)
//                self.setPriceLabels()
//                orders[index].setValue(self.viewModel.order.orderPrice, forKey: "price")
//                orders[index].setValue("Test Order Containing " + String((self.viewModel.order.orderItems.count)) + " Products", forKey: "desc")
//                if products.count <= 1{
//                    managedObjectContext.delete(orders[index])
//
//                }
//
//                try managedObjectContext.save()
//                ParamsUtil.sharedInstance.isOrderCacheUpdated = true
//
//            }
//
//
//        } catch {
//            //self.alertMessage = "Unable to Fetch Orders, (\(error))"
//
//        }
         
    }

    
    func saveChanges(){
        
        self.viewModel.updateProductquantity()
        
//        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
//        let managedObjectContext = appdelegate.persistentContainer.viewContext
//        let index = self.dataFromPreviousVC?.orderIndex ?? 0
//        let fetchRequest1: NSFetchRequest<Order> = Order.fetchRequest()
//        do {
//
//            let orders = try managedObjectContext.fetch(fetchRequest1)
//
//            if let products = orders[index].products as? Set<Product>{
//                for (tempObj,pobj) in zip(products,self.viewModel.order.orderItems){
//                    if let quan = pobj.qunatity {
//                        tempObj.setValue(String(quan), forKey: "quantity")
//                        try managedObjectContext.save()
//                    }
//
//                }
//            }
//
//
//            orders[index].setValue(self.viewModel.order.orderPrice, forKey: "price")
//            try managedObjectContext.save()
//            ParamsUtil.sharedInstance.isOrderCacheUpdated = true
//
//        } catch {
//            //self.alertMessage = "Unable to Fetch Orders, (\(error))"
//
//        }
    }
    
    
    
}

extension OrderdetailsVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "orderDetailCellIdentifier", for: indexPath) as? OrderDetailsTableViewCell else {
            fatalError("Cell not exists in storyboard")
        }
        
        let cellVM = viewModel.getCellViewModel( at: indexPath )
        cell.orderdetailsCellViewModel = cellVM
        cell.index = indexPath.row
        cell.delegate = self
        
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfCells
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
    
//    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
//       // self.viewModel.userPressed(at: indexPath)
//    }

}

protocol orderDetailButtonClick {
    func quantityDecrease(indexPath:Int)
    func qunatityIncrease(indexPath:Int)
    func deleteProduct(indexPath:Int)
}

class OrderDetailsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var plusBtn: UIButton!
    @IBOutlet weak var qunatity: UILabel!
    @IBOutlet weak var minusBtn: UIButton!
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var productImg: UIImageView!
    
    var index:Int?
    var delegate:orderDetailButtonClick?
    var orderdetailsCellViewModel : OrderDetailCellViewModel? {
        didSet {
            nameLabel.text = orderdetailsCellViewModel?.productNameText
            priceLabel.text = "Price: " + (orderdetailsCellViewModel?.productPriceText ?? "")
            qunatity.text = orderdetailsCellViewModel?.numOfproducts
            productImg?.sd_setImage(with: URL( string: orderdetailsCellViewModel?.imgUrl ?? "" ), placeholderImage: UIImage(named: "defaultProd"),completed: nil)
            let borderColor = UIColor(red:0, green:0, blue:0, alpha:1.0)
            productImg.layer.borderColor = borderColor.cgColor
            productImg.layer.borderWidth = 2.0
        }
    }
    
    @IBAction func minusClicked(_ sender: Any){
        self.delegate?.quantityDecrease(indexPath: index ?? 0)
        
    }
    @IBAction func plusClicked(_ sender: Any) {
        self.delegate?.qunatityIncrease(indexPath: index ?? 0)
        
    }
    @IBAction func deleteClicked(_ sender: Any) {
        self.delegate?.deleteProduct(indexPath: index ?? 0)
    }
}


