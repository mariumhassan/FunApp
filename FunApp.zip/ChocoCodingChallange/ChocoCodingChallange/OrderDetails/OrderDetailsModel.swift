//
//  ProductModel.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

struct OrderDetailsModel{
    
    var orderId:String
    var orderName:String
    var orderDesc:String
    var orderPrice:String
    var orderItems:[ProductModel]
   
}

extension Orders{
    
    init(orderItem:[ProductModel]){
        self.orderItems = orderItem
        self.orderId = ""
        self.orderPrice = ""
        self.orderDesc = ""
        self.orderName = ""
    }
}



