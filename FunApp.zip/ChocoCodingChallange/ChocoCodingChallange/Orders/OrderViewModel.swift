//
//  ViewController.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit
import CoreData

class OrderViewModel {

    //MARK: - Properties
    
    private var orderslist:[Orders]{
        didSet{
            ParamsUtil.sharedInstance.isOrderCacheUpdated = false
            self.processFetchedOrders(orders: orderslist)
        }
    }
    private var cellViewModels: [OrderListCellViewModel] = [OrderListCellViewModel]() {
        didSet {
            self.reloadTableViewClosure?()
        }
    }
    
    var numberOfCells:Int {
        return cellViewModels.count
    }
    
    var alertMessage:String?{
        
        didSet{
            self.showAlertClosure?()
        }
    }
    
    var showAlertClosure: (()->())?
    var reloadTableViewClosure: (()->())?
    
    
    // MARK: - Methods
    init(orderlist:[Orders] = [Orders]()) {
        self.orderslist = orderlist
    }
    
    func getCellViewModel( at indexPath: IndexPath ) -> OrderListCellViewModel {
        return cellViewModels[indexPath.row]
    }
    
    func getOrder( at indexPath: IndexPath ) -> Orders {
        self.orderslist[indexPath.row].orderIndex = indexPath.row
        return self.orderslist[indexPath.row]
    }
    
    private func processFetchedOrders( orders: [Orders] ) {
        var vms = [OrderListCellViewModel]()
        if orders.count > 0 {
            for order in orders {
                vms.append( createCellViewModel(order: order) )
            }
        }
        self.cellViewModels = vms
        
    }
    
    func fetchOrders(){
        
        do {
            self.orderslist =  try LocalDbManager.sharedInstance.fetchOrders()
        }catch{
            self.alertMessage = error.localizedDescription
            self.reloadTableViewClosure?()
        }
       
//        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
//        let managedObjectContext = appdelegate.persistentContainer.viewContext
//        var tempList = [Orders]()
//        let fetchRequest1: NSFetchRequest<Order> = Order.fetchRequest()
//        do {
//
//            let orders = try managedObjectContext.fetch(fetchRequest1)
//            for orderItem in orders{
//                var orderObj = Orders(orderId: orderItem.id ?? "", orderName: orderItem.name ?? "", orderDesc: orderItem.desc ?? "", orderPrice: orderItem.price ?? "", orderItems: [ProductModel]())
//                if let products = orderItem.products as? Set<Product>{
//                    for tempObj in products{
//
//                        let productObj = ProductModel(Id: tempObj.id, name: tempObj.name, Description: tempObj.desc, price: Int(tempObj.price ?? ""), photo: tempObj.photoUrl,qunatity: Int(tempObj.quantity ?? ""))
//                        orderObj.orderItems.append(productObj)
//
//
//                    }
//                }
//
//                tempList.append(orderObj)
//            }
//
//            self.orderslist = tempList
//
//        } catch {
//            self.alertMessage = "Unable to Fetch Orders, (\(error))"
//
//        }
        
    }
    
    func createCellViewModel( order: Orders ) -> OrderListCellViewModel {
    
        return OrderListCellViewModel( nameText: order.orderName ?? "",
                                       descText: order.orderDesc ?? "",
                                       priceText: ("Price: " + (order.orderPrice ?? "") ))
    }
    
    
}


struct OrderListCellViewModel {
    let nameText: String
    let descText: String
    let priceText: String
}

