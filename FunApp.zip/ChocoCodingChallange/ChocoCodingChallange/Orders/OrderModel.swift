//
//  ProductModel.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

struct Orders:Equatable{
    
    var orderId:String
    var orderName:String
    var orderDesc:String
    var orderPrice:String
    var orderItems:[ProductModel]
    var orderIndex:Int = 0
   
}

extension Orders{
    
    init(orderItem:[ProductModel]){
        self.orderItems = orderItem
        self.orderId = ""
        self.orderPrice = ""
        self.orderDesc = ""
        self.orderName = ""
    }
    
    init(){
        self.orderItems = [ProductModel]()
        self.orderId = ""
        self.orderPrice = ""
        self.orderDesc = ""
        self.orderName = ""
    }
}



