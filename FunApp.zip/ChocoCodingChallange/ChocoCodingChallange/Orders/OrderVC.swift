//
//  OrderVC.swift
//  ChocoCodingChallange
//
//  Created by Marium Hassan on 25/11/21.
//

import UIKit

class OrderVC: UIViewController {

    
    // MARK: Outlets
    @IBOutlet weak var tableViewheight: NSLayoutConstraint!
    @IBOutlet weak var NoRecordView: UIView!
    @IBOutlet weak var Indicator: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    // MARK: - Properties
    lazy var viewModel:OrderViewModel = {
        return OrderViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initView()
        initVM()
        self.NoRecordView.isHidden = true
        self.fetchOrdersList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.alpha = 1
        if ParamsUtil.sharedInstance.isOrderCacheUpdated{
            self.fetchOrdersList()
        }
    }
    
    override func viewWillLayoutSubviews() {
        super.updateViewConstraints()
        self.tableViewheight?.constant = self.tableView.contentSize.height
    }


    func initView(){
        self.navigationItem.title = "Orders"
        
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    func initVM(){

        viewModel.reloadTableViewClosure = { [weak self] () in
            DispatchQueue.main.async {
                if self?.viewModel.numberOfCells ?? 0 <= 0{
                    self?.tableView.isHidden = true
                    self?.NoRecordView.isHidden = false
                }else{
                    self?.NoRecordView.isHidden = true
                    self?.tableView.isHidden = false
                    self?.tableView.reloadData()
                }
                
            }
        }
        
    }
    
    func fetchOrdersList(){
        viewModel.fetchOrders()
    }
    
    func showAlert(_ message:String){
        AppUtility.showAlert(message)
    }
    
}

extension OrderVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "orderCellIdentifier", for: indexPath) as? OrderListTableViewCell else {
            fatalError("Cell not exists in storyboard")
        }
        
        let cellVM = viewModel.getCellViewModel( at: indexPath )
        cell.orderListCellViewModel = cellVM
        
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfCells
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let order = self.viewModel.getOrder(at: indexPath)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "OrderdetailsVC") as! OrderdetailsVC
        vc.dataFromPreviousVC = order
        self.navigationController?.pushViewController(vc, animated: true)
    }


}



class OrderListTableViewCell: UITableViewCell {
    @IBOutlet weak var selectBtn: UIButton!
    @IBOutlet weak var mainImageView: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descContainerHeightConstraint: NSLayoutConstraint!
    var orderListCellViewModel : OrderListCellViewModel? {
        didSet {
            nameLabel.text = orderListCellViewModel?.nameText
            descriptionLabel.text = orderListCellViewModel?.descText
            priceLabel.text = orderListCellViewModel?.priceText
        }
    }
}


